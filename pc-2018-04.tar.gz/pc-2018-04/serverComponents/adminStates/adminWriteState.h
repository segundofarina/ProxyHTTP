#ifndef _ADMIN_WRITE_STATE_H_
#define _ADMIN_WRITE_STATE_H_

#include <sys/types.h>

#include "../../utils/selector/selector.h"

unsigned adminWrite(struct selector_key * key);

#endif
