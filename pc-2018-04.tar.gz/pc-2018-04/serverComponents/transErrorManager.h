#ifndef _TRANS_ERROR_MANAGER_H_
#define _TRANS_ERROR_MANAGER_H_

#define TRANS_ERR_MAX_LEN 256

int setTransformationErrorFile(const char * str);

char * getTransformationErrorFile();

#endif
