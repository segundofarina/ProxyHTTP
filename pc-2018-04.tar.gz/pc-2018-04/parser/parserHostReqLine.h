//
//  Created by Nicolas Paganini on 5/27/18
//

#ifndef PC_2018_04_PARSERHOSTREQLINE_H
#define PC_2018_04_PARSERHOSTREQLINE_H

#include <stdlib.h>
#include <ctype.h>
#include <stdint.h>
#include <string.h>
// #include <netinet/in.h>
// #include <inttypes.h>
// #include <sys/types.h>
// #include <sys/socket.h>
// #include <netdb.h>
#include <arpa/inet.h>

#define DEFAULT_HTTP_PORT (80)

typedef enum {ERROR_hostData = 0, EMPTY, DOMAIN_HOST, DOMAIN_HOST_PORT, IPV4, IPV4_PORT, IPV6, IPV6_PORT} hostData;

//	As per RFC:7230
//	request-line = method SP request-target SP HTTP-version CRLF
typedef enum {METHOD, SP1, REQ_TAR, SP2, HTTPV, CRLF} reqLineState;

typedef enum {START, HTTP, SLASH, HOST, DOUBLE_DOT, PORT} validHostState;

enum addrType {
    IPv4, IPv6, DOMAIN
};

union socks_addr {
    char fqdn[0xff];
    struct sockaddr_in  ipv4;
    struct sockaddr_in6 ipv6;
};

struct requestData {
    enum addrType destAddrType;
    union socks_addr destAddr;
    /** port in network byte order */
    in_port_t destPort;
};


/**
 *	|	Valid hosts:				|			Host		|  port
 *	-----------------------------------------------------------------
 *	|	/ 							|			EMPTY		|	80
 *	|	/background.png				|			EMPTY		|	80
 *	|	/test.html?query=alibaba	|			EMPTY		|	80
 *	|	/anypage.html				|		    EMPTY		|	80
 *	|	http://google.com/docs		|		google.com		|	80
 *	|	google.com:1080				|		google.com		|  1080
 *	|	127.0.0.1					|		127.0.0.1		|	80
 *	|	127.0.0.1:1080				|		127.0.0.1		|  1080
 *	|	http://[AAAA]:8080			|		AAAA host 		|  8080
 *	=================================================================
 *	|	Invalid hosts: ERROR		|			Host		|  port
 *	-----------------------------------------------------------------
 *	|	:1080						|			EMPTY		|  1080
*/
hostData processHost(char * fqdn, char * result, uint16_t resultLen, uint16_t * port);

/**
 *	The return value is as follows:
 *	ERROR: Code 400 (bad request)
 *	EMPTY: host not found, only request-target present
 *	DOMAIN_HOST: host found as domain name, must be resolved
 *	DOMAIN_HOST_PORT: host found as domain name with port
 *	IPV4: host found as IPv4
 *	IPV4_PORT: host found as IPv4 with port
 *	IPV6: host found as IPv6
 *	IPV6_PORT: host found as IPv6 with port
 */
hostData requestTarget_marshall(char * buffer, char * result, uint16_t resultLen, uint16_t * port);

/**
 *	Fills the Request Data struct with the available data. If there's no specified
 *	port, the default port for HTTP is port 80.
 *	Note: a request-line with a request-target that does not contain the host
 *	qualifies as EMPTY and is a successful request.
 *
 *	Returns:
 *		1 on success
 *		0 if parameter host does not contain a valid IPv4 or IPv6 address
 *	   -1 is returned if parameter addressType isn't a valid address type
**/
int fillRequestData_marshall(hostData addressType, char * host, uint16_t port, struct requestData * rdStruct);

#endif
