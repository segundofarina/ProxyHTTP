//
// Created by Segundo Fariña on 11/6/18.
//

#ifndef PC_2018_04_PARSER_ERRORCODES_H
#define PC_2018_04_PARSER_ERRORCODES_H


enum parser_errorCode{
    ERROR_BAD_REQUEST=400,
    ERROR_METHOD_NOT_IMPLEMENTED=501,
    OK,
};


#endif //PC_2018_04_PARSER_ERRORCODES_H
