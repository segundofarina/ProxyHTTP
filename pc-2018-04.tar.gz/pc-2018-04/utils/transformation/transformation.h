#ifndef _TRANSFORMATION_H_
#define _TRANSFORMATION_H_

void chunkBody(char * buffer, int * bLen, char * ans, int * aLen);

#endif
